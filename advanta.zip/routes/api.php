<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use App\Models\User;
use App\Models\Project;
use App\Models\Requisition;
use App\Models\RequisitionItem;
use App\Models\RequisitionApproval;
use App\Models\Lpo;
use App\Models\LpoItem;
use App\Models\LpoReceivedItem;
use App\Models\Supplier;
use App\Models\Store;
use App\Models\InventoryItem;
use App\Models\InventoryLog;
use App\Models\StoreRelease;
use App\Models\StoreReleaseItem;
use App\Models\Payment;
use App\Models\Expense;
use App\Models\ProductCatalog;
use App\Models\ProductCategory;
use App\Models\ProjectMilestone;
use App\Models\LaborWorker;
use App\Models\LaborPayment;
use App\Models\Subcontractor;
use App\Models\SubcontractorPayment;
use App\Models\ProjectSubcontractor;
use App\Models\StaffReport;
use App\Models\QhseReport;
use App\Models\InAppNotification;

/*
|--------------------------------------------------------------------------
| API Routes for Advanta Flutter Mobile App
|--------------------------------------------------------------------------
| Construction Project Management & Procurement System
| Token-based authentication using Laravel Sanctum
| All responses are JSON format
*/

// ====================
// PUBLIC ROUTES (No Authentication Required)
// ====================

// Health check
Route::get('/health', function () {
    return response()->json([
        'status' => 'ok',
        'message' => 'Advanta API is running',
        'timestamp' => now()->toISOString(),
        'version' => '1.0.0',
    ]);
});

// Authentication - Login
Route::post('/login', function (Request $request) {
    $request->validate([
        'email' => 'required|email',
        'password' => 'required',
    ]);

    $user = User::where('email', $request->email)->first();

    if (!$user || !Hash::check($request->password, $user->password)) {
        throw ValidationException::withMessages([
            'email' => ['The provided credentials are incorrect.'],
        ]);
    }

    // Create a new token
    $token = $user->createToken('mobile-app-' . $user->role)->plainTextToken;

    return response()->json([
        'success' => true,
        'message' => 'Login successful',
        'token' => $token,
        'user' => [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'role' => $user->role,
            'shop_id' => $user->shop_id,
            'back_debt' => $user->back_debt,
            'created_at' => $user->created_at,
        ],
    ]);
});

// Staff Reports - Public submission with access code
Route::post('/public/staff-reports', function (Request $request) {
    $request->validate([
        'access_code' => 'required|string',
        'reporter_name' => 'required|string|max:255',
        'reporter_email' => 'nullable|email',
        'report_type' => 'required|in:daily,weekly',
        'project_id' => 'required|exists:projects,id',
        'date' => 'required|date',
        'content' => 'required|string',
        'attachments.*' => 'nullable|file|max:10240', // 10MB max
    ]);

    // Validate access code
    if ($request->access_code !== 'ADVANTA2024') {
        return response()->json([
            'success' => false,
            'message' => 'Invalid access code',
        ], 403);
    }

    $attachments = [];
    if ($request->hasFile('attachments')) {
        foreach ($request->file('attachments') as $file) {
            $path = $file->store('staff-reports', 'public');
            $attachments[] = $path;
        }
    }

    $report = StaffReport::create([
        'reporter_name' => $request->reporter_name,
        'reporter_email' => $request->reporter_email,
        'report_type' => $request->report_type,
        'project_id' => $request->project_id,
        'date' => $request->date,
        'content' => $request->content,
        'attachments' => json_encode($attachments),
    ]);

    return response()->json([
        'success' => true,
        'message' => 'Report submitted successfully',
        'data' => $report,
    ], 201);
});

// QHSE Reports - Public submission with access code
Route::post('/public/qhse-reports', function (Request $request) {
    $request->validate([
        'access_code' => 'required|string',
        'reporter_name' => 'required|string|max:255',
        'reporter_email' => 'nullable|email',
        'report_type' => 'required|in:safety,quality,health,environment,incident,companydocuments',
        'project_id' => 'required|exists:projects,id',
        'incident_date' => 'required|date',
        'description' => 'required|string',
        'severity' => 'nullable|in:low,medium,high,critical',
        'attachments.*' => 'nullable|file|max:10240',
    ]);

    // Validate access code
    if ($request->access_code !== 'QHSE2024') {
        return response()->json([
            'success' => false,
            'message' => 'Invalid access code',
        ], 403);
    }

    $attachments = [];
    if ($request->hasFile('attachments')) {
        foreach ($request->file('attachments') as $file) {
            $path = $file->store('qhse-reports', 'public');
            $attachments[] = $path;
        }
    }

    $report = QhseReport::create([
        'reporter_name' => $request->reporter_name,
        'reporter_email' => $request->reporter_email,
        'report_type' => $request->report_type,
        'project_id' => $request->project_id,
        'incident_date' => $request->incident_date,
        'description' => $request->description,
        'severity' => $request->severity ?? 'medium',
        'attachments' => json_encode($attachments),
    ]);

    return response()->json([
        'success' => true,
        'message' => 'QHSE report submitted successfully',
        'data' => $report,
    ], 201);
});

// ====================
// AUTHENTICATED ROUTES
// ====================
Route::middleware('auth:sanctum')->group(function () {

    // Logout
    Route::post('/logout', function (Request $request) {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['success' => true, 'message' => 'Logged out successfully']);
    });

    // Get current user
    Route::get('/user', function (Request $request) {
        $user = $request->user();
        return response()->json([
            'success' => true,
            'data' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'phone' => $user->phone,
                'role' => $user->role,
                'shop_id' => $user->shop_id,
                'back_debt' => $user->back_debt,
                'created_at' => $user->created_at,
            ],
        ]);
    });

    // Update Profile
    Route::put('/user/profile', function (Request $request) {
        $request->validate([
            'name' => 'sometimes|string|max:255',
            'phone' => 'sometimes|string|max:255',
        ]);

        $user = $request->user();
        $user->update($request->only(['name', 'phone']));

        return response()->json([
            'success' => true,
            'message' => 'Profile updated successfully',
            'data' => $user,
        ]);
    });

    // Change Password
    Route::put('/user/change-password', function (Request $request) {
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|min:8|confirmed',
        ]);

        $user = $request->user();

        if (!Hash::check($request->current_password, $user->password)) {
            return response()->json(['success' => false, 'message' => 'Current password is incorrect'], 400);
        }

        $user->password = Hash::make($request->new_password);
        $user->save();

        return response()->json(['success' => true, 'message' => 'Password changed successfully']);
    });

    // ==================== DASHBOARD ====================
    Route::get('/dashboard', function (Request $request) {
        $user = $request->user();
        $stats = [];

        // Role-based dashboard stats
        switch ($user->role) {
            case 'admin':
            case 'ceo':
                $stats = [
                    'total_projects' => Project::count(),
                    'active_projects' => Project::where('status', 'active')->count(),
                    'total_users' => User::count(),
                    'pending_requisitions' => Requisition::where('status', 'pending')->count(),
                    'pending_payments' => Payment::where('status', 'pending_ceo')->count(),
                    'total_suppliers' => Supplier::count(),
                    'total_inventory_value' => InventoryItem::sum(DB::raw('current_stock * unit_price')),
                    'monthly_expenses' => Expense::whereMonth('created_at', now()->month)->sum('amount'),
                ];
                break;

            case 'finance':
                $stats = [
                    'pending_payments' => Payment::whereIn('status', ['pending', 'pending_ceo'])->count(),
                    'approved_payments' => Payment::where('status', 'ceo_approved')->count(),
                    'total_payments' => Payment::whereMonth('created_at', now()->month)->sum('amount'),
                    'total_expenses' => Expense::whereMonth('created_at', now()->month)->sum('amount'),
                    'labor_workers' => LaborWorker::count(),
                    'pending_labor_payments' => LaborPayment::where('status', 'pending')->count(),
                ];
                break;

            case 'procurement':
                $stats = [
                    'pending_requisitions' => Requisition::where('status', 'procurement')->count(),
                    'total_lpos' => Lpo::count(),
                    'pending_lpos' => Lpo::where('status', 'pending')->count(),
                    'delivered_lpos' => Lpo::where('status', 'delivered')->count(),
                    'total_suppliers' => Supplier::count(),
                ];
                break;

            case 'stores':
                $stats = [
                    'total_stores' => Store::count(),
                    'total_inventory_items' => InventoryItem::count(),
                    'low_stock_items' => InventoryItem::whereColumn('current_stock', '<=', 'reorder_level')->count(),
                    'pending_releases' => StoreRelease::where('status', 'pending')->count(),
                    'pending_lpo_deliveries' => Lpo::where('status', 'issued')->count(),
                ];
                break;

            case 'project_manager':
            case 'engineer':
                $userProjects = $user->projects->pluck('id');
                $stats = [
                    'my_projects' => $user->projects->count(),
                    'my_requisitions' => Requisition::where('requested_by', $user->id)->count(),
                    'pending_requisitions' => Requisition::where('requested_by', $user->id)
                        ->where('status', 'pending')->count(),
                    'approved_requisitions' => Requisition::where('requested_by', $user->id)
                        ->whereIn('status', ['completed', 'lpo_issued'])->count(),
                ];
                break;

            case 'surveyor':
                $userProjects = $user->projects->pluck('id');
                $stats = [
                    'my_projects' => $user->projects->count(),
                    'total_milestones' => ProjectMilestone::whereIn('project_id', $userProjects)->count(),
                    'completed_milestones' => ProjectMilestone::whereIn('project_id', $userProjects)
                        ->where('status', 'completed')->count(),
                    'delayed_milestones' => ProjectMilestone::whereIn('project_id', $userProjects)
                        ->where('status', 'delayed')->count(),
                ];
                break;

            default:
                $stats = ['message' => 'Dashboard stats not configured for this role'];
        }

        // Get recent notifications
        $notifications = InAppNotification::where('user_id', $user->id)
            ->orderBy('created_at', 'desc')
            ->take(10)
            ->get();

        return response()->json([
            'success' => true,
            'stats' => $stats,
            'notifications' => $notifications,
            'user_role' => $user->role,
        ]);
    });

    // ==================== PROJECTS ====================
    Route::prefix('projects')->group(function () {

        // Get all projects
        Route::get('/', function (Request $request) {
            $user = $request->user();
            $query = Project::query();

            // Filter by user's assigned projects for non-admin/ceo roles
            if (!in_array($user->role, ['admin', 'ceo'])) {
                $projectIds = $user->projects->pluck('id');
                $query->whereIn('id', $projectIds);
            }

            // Filter by status
            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            $projects = $query->orderBy('created_at', 'desc')->get();

            return response()->json([
                'success' => true,
                'data' => $projects,
            ]);
        });

        // Get single project
        Route::get('/{id}', function (Request $request, $id) {
            $project = Project::with(['milestones', 'stores'])->find($id);

            if (!$project) {
                return response()->json(['success' => false, 'message' => 'Project not found'], 404);
            }

            // Check access
            $user = $request->user();
            if (!in_array($user->role, ['admin', 'ceo']) && !$user->projects->contains($id)) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            return response()->json([
                'success' => true,
                'data' => $project,
            ]);
        });

        // Create project (Admin only)
        Route::post('/', function (Request $request) {
            if (!in_array($request->user()->role, ['admin', 'ceo'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'code' => 'nullable|string|max:255|unique:projects,code',
                'name' => 'required|string|max:255',
                'description' => 'nullable|string',
                'location' => 'nullable|string|max:255',
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
                'budget' => 'nullable|numeric|min:0',
            ]);

            $project = Project::create($request->all());

            return response()->json([
                'success' => true,
                'message' => 'Project created successfully',
                'data' => $project,
            ], 201);
        });

        // Update project (Admin only)
        Route::put('/{id}', function (Request $request, $id) {
            if (!in_array($request->user()->role, ['admin', 'ceo'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $project = Project::find($id);
            if (!$project) {
                return response()->json(['success' => false, 'message' => 'Project not found'], 404);
            }

            $request->validate([
                'code' => 'nullable|string|max:255|unique:projects,code,' . $id,
                'name' => 'sometimes|required|string|max:255',
                'description' => 'nullable|string',
                'location' => 'nullable|string|max:255',
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
                'budget' => 'nullable|numeric|min:0',
                'status' => 'nullable|in:active,completed,on_hold',
            ]);

            $project->update($request->all());

            return response()->json([
                'success' => true,
                'message' => 'Project updated successfully',
                'data' => $project,
            ]);
        });

        // Get project milestones
        Route::get('/{id}/milestones', function ($id) {
            $milestones = ProjectMilestone::where('project_id', $id)
                ->orderBy('milestone_number')
                ->get();

            return response()->json([
                'success' => true,
                'data' => $milestones,
            ]);
        });

        // Get project requisitions
        Route::get('/{id}/requisitions', function ($id) {
            $requisitions = Requisition::with(['requestedBy', 'items'])
                ->where('project_id', $id)
                ->orderBy('created_at', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'data' => $requisitions,
            ]);
        });

        // Get project inventory
        Route::get('/{id}/inventory', function ($id) {
            $stores = Store::where('project_id', $id)
                ->with(['inventoryItems'])
                ->get();

            return response()->json([
                'success' => true,
                'data' => $stores,
            ]);
        });
    });

    // ==================== REQUISITIONS ====================
    Route::prefix('requisitions')->group(function () {

        // Get all requisitions
        Route::get('/', function (Request $request) {
            $user = $request->user();
            $query = Requisition::with(['project', 'requestedBy', 'items', 'store']);

            // Role-based filtering
            switch ($user->role) {
                case 'engineer':
                case 'project_manager':
                    $query->where('requested_by', $user->id);
                    break;
                case 'operations':
                    $query->whereIn('status', ['pending', 'project_manager_approved']);
                    break;
                case 'procurement':
                    $query->whereIn('status', ['operations_approved', 'procurement', 'ceo_approved']);
                    break;
                case 'ceo':
                    $query->where('status', 'operations_approved')
                        ->orWhere('status', 'ceo_approved')
                        ->orWhere('status', 'procurement');
                    break;
                case 'stores':
                    $query->where('type', 'store')
                        ->whereIn('status', ['project_manager_approved', 'completed']);
                    break;
            }

            // Filter by status
            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            // Filter by type
            if ($request->has('type')) {
                $query->where('type', $request->type);
            }

            // Filter by project
            if ($request->has('project_id')) {
                $query->where('project_id', $request->project_id);
            }

            $perPage = $request->get('per_page', 20);
            $requisitions = $query->orderBy('created_at', 'desc')->paginate($perPage);

            return response()->json([
                'success' => true,
                'data' => $requisitions->items(),
                'meta' => [
                    'current_page' => $requisitions->currentPage(),
                    'last_page' => $requisitions->lastPage(),
                    'total' => $requisitions->total(),
                ],
            ]);
        });

        // Get single requisition
        Route::get('/{id}', function ($id) {
            $requisition = Requisition::with(['project', 'requestedBy', 'items', 'approvals.approvedBy', 'store'])
                ->find($id);

            if (!$requisition) {
                return response()->json(['success' => false, 'message' => 'Requisition not found'], 404);
            }

            return response()->json([
                'success' => true,
                'data' => $requisition,
            ]);
        });

        // Create requisition
        Route::post('/', function (Request $request) {
            $request->validate([
                'project_id' => 'required|exists:projects,id',
                'type' => 'required|in:store,purchase',
                'urgency' => 'required|in:low,normal,high',
                'reason' => 'nullable|string',
                'store_id' => 'required_if:type,store|exists:stores,id',
                'items' => 'required|array|min:1',
                'items.*.product_catalog_id' => 'nullable|exists:product_catalogs,id',
                'items.*.item_description' => 'required|string',
                'items.*.quantity' => 'required|numeric|min:0.01',
                'items.*.unit' => 'required|string',
                'items.*.estimated_unit_price' => 'nullable|numeric|min:0',
            ]);

            DB::beginTransaction();
            try {
                // Generate reference number
                $ref = 'REQ-' . strtoupper(uniqid()) . '-' . date('Ymd');

                // Calculate estimated total
                $estimatedTotal = 0;
                foreach ($request->items as $item) {
                    $estimatedTotal += ($item['quantity'] ?? 0) * ($item['estimated_unit_price'] ?? 0);
                }

                $requisition = Requisition::create([
                    'ref' => $ref,
                    'project_id' => $request->project_id,
                    'requested_by' => $request->user()->id,
                    'type' => $request->type,
                    'urgency' => $request->urgency,
                    'reason' => $request->reason,
                    'store_id' => $request->store_id,
                    'status' => 'pending',
                    'estimated_total' => $estimatedTotal,
                ]);

                // Create requisition items
                foreach ($request->items as $item) {
                    RequisitionItem::create([
                        'requisition_id' => $requisition->id,
                        'product_catalog_id' => $item['product_catalog_id'] ?? null,
                        'item_description' => $item['item_description'],
                        'quantity' => $item['quantity'],
                        'unit' => $item['unit'],
                        'estimated_unit_price' => $item['estimated_unit_price'] ?? 0,
                    ]);
                }

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'Requisition created successfully',
                    'data' => $requisition->load(['items']),
                ], 201);

            } catch (\Exception $e) {
                DB::rollBack();
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to create requisition: ' . $e->getMessage(),
                ], 500);
            }
        });

        // Approve/Reject requisition
        Route::post('/{id}/approve', function (Request $request, $id) {
            $request->validate([
                'action' => 'required|in:approve,reject',
                'comments' => 'nullable|string',
            ]);

            $requisition = Requisition::find($id);
            if (!$requisition) {
                return response()->json(['success' => false, 'message' => 'Requisition not found'], 404);
            }

            $user = $request->user();
            $currentStatus = $requisition->status;
            $newStatus = null;

            // Determine new status based on role and current status
            if ($request->action === 'approve') {
                switch ($user->role) {
                    case 'project_manager':
                        if ($currentStatus === 'pending') {
                            $newStatus = 'project_manager_approved';
                        }
                        break;
                    case 'operations':
                        if ($currentStatus === 'project_manager_approved' && $requisition->type === 'purchase') {
                            $newStatus = 'operations_approved';
                        }
                        break;
                    case 'ceo':
                        if ($currentStatus === 'operations_approved' || $currentStatus === 'procurement') {
                            $newStatus = 'ceo_approved';
                        }
                        break;
                }
            } else {
                $newStatus = 'rejected';
            }

            if (!$newStatus) {
                return response()->json([
                    'success' => false,
                    'message' => 'You cannot perform this action on this requisition',
                ], 403);
            }

            DB::beginTransaction();
            try {
                // Update requisition status
                $requisition->update(['status' => $newStatus]);

                // Record approval
                RequisitionApproval::create([
                    'requisition_id' => $requisition->id,
                    'approved_by' => $user->id,
                    'action' => $request->action,
                    'comments' => $request->comments,
                    'role' => $user->role,
                ]);

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => ucfirst($request->action) . 'd successfully',
                    'data' => $requisition->fresh(['approvals']),
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to process approval: ' . $e->getMessage(),
                ], 500);
            }
        });
    });

    // ==================== LPOs (Local Purchase Orders) ====================
    Route::prefix('lpos')->group(function () {

        // Get all LPOs
        Route::get('/', function (Request $request) {
            $query = Lpo::with(['supplier', 'requisition', 'items']);

            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('supplier_id')) {
                $query->where('supplier_id', $request->supplier_id);
            }

            $perPage = $request->get('per_page', 20);
            $lpos = $query->orderBy('created_at', 'desc')->paginate($perPage);

            return response()->json([
                'success' => true,
                'data' => $lpos->items(),
                'meta' => [
                    'current_page' => $lpos->currentPage(),
                    'last_page' => $lpos->lastPage(),
                    'total' => $lpos->total(),
                ],
            ]);
        });

        // Get single LPO
        Route::get('/{id}', function ($id) {
            $lpo = Lpo::with(['supplier', 'requisition', 'items', 'receivedItems'])->find($id);

            if (!$lpo) {
                return response()->json(['success' => false, 'message' => 'LPO not found'], 404);
            }

            return response()->json([
                'success' => true,
                'data' => $lpo,
            ]);
        });

        // Create LPO (Procurement role)
        Route::post('/', function (Request $request) {
            if ($request->user()->role !== 'procurement') {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'requisition_id' => 'required|exists:requisitions,id',
                'supplier_id' => 'required|exists:suppliers,id',
                'delivery_date' => 'nullable|date',
                'terms' => 'nullable|string',
                'items' => 'required|array|min:1',
                'items.*.requisition_item_id' => 'required|exists:requisition_items,id',
                'items.*.quantity' => 'required|numeric|min:0.01',
                'items.*.unit_price' => 'required|numeric|min:0',
                'items.*.has_vat' => 'nullable|boolean',
            ]);

            DB::beginTransaction();
            try {
                // Generate LPO number
                $lpoNumber = 'LPO-' . strtoupper(uniqid()) . '-' . date('Ymd');

                // Calculate totals
                $subtotal = 0;
                $vatAmount = 0;
                foreach ($request->items as $item) {
                    $itemTotal = $item['quantity'] * $item['unit_price'];
                    $subtotal += $itemTotal;
                    if ($item['has_vat'] ?? false) {
                        $vatAmount += $itemTotal * 0.18; // 18% VAT
                    }
                }
                $total = $subtotal + $vatAmount;

                $lpo = Lpo::create([
                    'lpo_number' => $lpoNumber,
                    'requisition_id' => $request->requisition_id,
                    'supplier_id' => $request->supplier_id,
                    'issued_by' => $request->user()->id,
                    'delivery_date' => $request->delivery_date,
                    'terms' => $request->terms,
                    'subtotal' => $subtotal,
                    'vat_amount' => $vatAmount,
                    'total' => $total,
                    'status' => 'pending',
                ]);

                // Create LPO items
                foreach ($request->items as $item) {
                    LpoItem::create([
                        'lpo_id' => $lpo->id,
                        'requisition_item_id' => $item['requisition_item_id'],
                        'quantity' => $item['quantity'],
                        'unit_price' => $item['unit_price'],
                        'has_vat' => $item['has_vat'] ?? false,
                    ]);
                }

                // Update requisition status
                $requisition = Requisition::find($request->requisition_id);
                $requisition->update(['status' => 'lpo_issued']);

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'LPO created successfully',
                    'data' => $lpo->load(['items']),
                ], 201);

            } catch (\Exception $e) {
                DB::rollBack();
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to create LPO: ' . $e->getMessage(),
                ], 500);
            }
        });

        // Mark LPO as delivered (Stores role)
        Route::post('/{id}/deliver', function (Request $request, $id) {
            if ($request->user()->role !== 'stores') {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'items' => 'required|array',
                'items.*.lpo_item_id' => 'required|exists:lpo_items,id',
                'items.*.received_quantity' => 'required|numeric|min:0',
                'items.*.notes' => 'nullable|string',
            ]);

            $lpo = Lpo::find($id);
            if (!$lpo) {
                return response()->json(['success' => false, 'message' => 'LPO not found'], 404);
            }

            DB::beginTransaction();
            try {
                foreach ($request->items as $item) {
                    LpoReceivedItem::create([
                        'lpo_item_id' => $item['lpo_item_id'],
                        'received_quantity' => $item['received_quantity'],
                        'received_by' => $request->user()->id,
                        'notes' => $item['notes'] ?? null,
                    ]);
                }

                $lpo->update(['status' => 'delivered']);

                // Update requisition status
                $lpo->requisition->update(['status' => 'delivered']);

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'LPO marked as delivered',
                    'data' => $lpo->fresh(['receivedItems']),
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to process delivery: ' . $e->getMessage(),
                ], 500);
            }
        });
    });

    // ==================== SUPPLIERS ====================
    Route::prefix('suppliers')->group(function () {

        Route::get('/', function (Request $request) {
            $suppliers = Supplier::orderBy('name')->get();
            return response()->json(['success' => true, 'data' => $suppliers]);
        });

        Route::get('/{id}', function ($id) {
            $supplier = Supplier::with(['lpos'])->find($id);
            if (!$supplier) {
                return response()->json(['success' => false, 'message' => 'Supplier not found'], 404);
            }
            return response()->json(['success' => true, 'data' => $supplier]);
        });

        Route::post('/', function (Request $request) {
            if (!in_array($request->user()->role, ['admin', 'procurement'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'name' => 'required|string|max:255',
                'contact_person' => 'nullable|string|max:255',
                'email' => 'nullable|email',
                'phone' => 'nullable|string|max:255',
                'address' => 'nullable|string',
                'category' => 'nullable|string|max:255',
            ]);

            $supplier = Supplier::create($request->all());

            return response()->json([
                'success' => true,
                'message' => 'Supplier created successfully',
                'data' => $supplier,
            ], 201);
        });

        Route::put('/{id}', function (Request $request, $id) {
            if (!in_array($request->user()->role, ['admin', 'procurement'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $supplier = Supplier::find($id);
            if (!$supplier) {
                return response()->json(['success' => false, 'message' => 'Supplier not found'], 404);
            }

            $request->validate([
                'name' => 'sometimes|required|string|max:255',
                'contact_person' => 'nullable|string|max:255',
                'email' => 'nullable|email',
                'phone' => 'nullable|string|max:255',
                'address' => 'nullable|string',
                'category' => 'nullable|string|max:255',
            ]);

            $supplier->update($request->all());

            return response()->json([
                'success' => true,
                'message' => 'Supplier updated successfully',
                'data' => $supplier,
            ]);
        });
    });

    // ==================== INVENTORY & STORES ====================
    Route::prefix('inventory')->group(function () {

        // Get all stores
        Route::get('/stores', function (Request $request) {
            $query = Store::query();

            if ($request->has('type')) {
                $query->where('type', $request->type);
            }

            if ($request->has('project_id')) {
                $query->where('project_id', $request->project_id);
            }

            $stores = $query->with(['project'])->get();

            return response()->json(['success' => true, 'data' => $stores]);
        });

        // Get store items
        Route::get('/stores/{id}/items', function ($id) {
            $store = Store::with(['inventoryItems.productCatalog'])->find($id);

            if (!$store) {
                return response()->json(['success' => false, 'message' => 'Store not found'], 404);
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'store' => $store,
                    'items' => $store->inventoryItems,
                ],
            ]);
        });

        // Search inventory items
        Route::get('/items/search', function (Request $request) {
            $query = InventoryItem::with(['store', 'productCatalog']);

            if ($request->has('store_id')) {
                $query->where('store_id', $request->store_id);
            }

            if ($request->has('search')) {
                $search = $request->search;
                $query->where(function ($q) use ($search) {
                    $q->where('item_name', 'like', "%{$search}%")
                      ->orWhere('item_code', 'like', "%{$search}%");
                });
            }

            if ($request->has('low_stock') && $request->low_stock) {
                $query->whereColumn('current_stock', '<=', 'reorder_level');
            }

            $items = $query->orderBy('item_name')->get();

            return response()->json(['success' => true, 'data' => $items]);
        });

        // Get inventory logs
        Route::get('/logs', function (Request $request) {
            $query = InventoryLog::with(['inventoryItem', 'user']);

            if ($request->has('store_id')) {
                $query->whereHas('inventoryItem', function ($q) use ($request) {
                    $q->where('store_id', $request->store_id);
                });
            }

            $perPage = $request->get('per_page', 20);
            $logs = $query->orderBy('created_at', 'desc')->paginate($perPage);

            return response()->json([
                'success' => true,
                'data' => $logs->items(),
                'meta' => [
                    'current_page' => $logs->currentPage(),
                    'last_page' => $logs->lastPage(),
                    'total' => $logs->total(),
                ],
            ]);
        });
    });

    // ==================== PAYMENTS ====================
    Route::prefix('payments')->group(function () {

        // Get all payments
        Route::get('/', function (Request $request) {
            $query = Payment::with(['lpo.supplier', 'paidBy']);

            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            $perPage = $request->get('per_page', 20);
            $payments = $query->orderBy('created_at', 'desc')->paginate($perPage);

            return response()->json([
                'success' => true,
                'data' => $payments->items(),
                'meta' => [
                    'current_page' => $payments->currentPage(),
                    'last_page' => $payments->lastPage(),
                    'total' => $payments->total(),
                ],
            ]);
        });

        // Get single payment
        Route::get('/{id}', function ($id) {
            $payment = Payment::with(['lpo.supplier', 'paidBy'])->find($id);

            if (!$payment) {
                return response()->json(['success' => false, 'message' => 'Payment not found'], 404);
            }

            return response()->json(['success' => true, 'data' => $payment]);
        });

        // Create payment (Finance role)
        Route::post('/', function (Request $request) {
            if (!in_array($request->user()->role, ['finance', 'admin'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'lpo_id' => 'required|exists:lpos,id',
                'amount' => 'required|numeric|min:0',
                'payment_method' => 'required|in:cash,bank_transfer,cheque,mobile_money',
                'payment_date' => 'required|date',
                'reference' => 'nullable|string|max:255',
                'voucher' => 'nullable|file|max:5120',
            ]);

            $voucher = null;
            if ($request->hasFile('voucher')) {
                $voucher = $request->file('voucher')->store('payment-vouchers', 'public');
            }

            $payment = Payment::create([
                'lpo_id' => $request->lpo_id,
                'amount' => $request->amount,
                'payment_method' => $request->payment_method,
                'payment_date' => $request->payment_date,
                'reference' => $request->reference,
                'voucher' => $voucher,
                'paid_by' => $request->user()->id,
                'status' => 'pending_ceo',
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Payment created and pending CEO approval',
                'data' => $payment,
            ], 201);
        });

        // Approve/Reject payment (CEO role)
        Route::post('/{id}/approve', function (Request $request, $id) {
            if ($request->user()->role !== 'ceo') {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'action' => 'required|in:approve,reject',
                'comments' => 'nullable|string',
            ]);

            $payment = Payment::find($id);
            if (!$payment) {
                return response()->json(['success' => false, 'message' => 'Payment not found'], 404);
            }

            $status = $request->action === 'approve' ? 'ceo_approved' : 'ceo_rejected';
            $payment->update([
                'status' => $status,
                'approval_comments' => $request->comments,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Payment ' . $request->action . 'd successfully',
                'data' => $payment,
            ]);
        });
    });

    // ==================== EXPENSES ====================
    Route::prefix('expenses')->group(function () {

        Route::get('/', function (Request $request) {
            $query = Expense::with(['project', 'createdBy']);

            if ($request->has('project_id')) {
                $query->where('project_id', $request->project_id);
            }

            if ($request->has('category')) {
                $query->where('category', $request->category);
            }

            $perPage = $request->get('per_page', 20);
            $expenses = $query->orderBy('date', 'desc')->paginate($perPage);

            return response()->json([
                'success' => true,
                'data' => $expenses->items(),
                'meta' => [
                    'current_page' => $expenses->currentPage(),
                    'last_page' => $expenses->lastPage(),
                    'total' => $expenses->total(),
                ],
            ]);
        });

        Route::post('/', function (Request $request) {
            if (!in_array($request->user()->role, ['finance', 'admin'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'project_id' => 'nullable|exists:projects,id',
                'category' => 'required|string|max:255',
                'description' => 'required|string',
                'amount' => 'required|numeric|min:0',
                'date' => 'required|date',
                'receipt' => 'nullable|file|max:5120',
            ]);

            $receipt = null;
            if ($request->hasFile('receipt')) {
                $receipt = $request->file('receipt')->store('expense-receipts', 'public');
            }

            $expense = Expense::create([
                'project_id' => $request->project_id,
                'category' => $request->category,
                'description' => $request->description,
                'amount' => $request->amount,
                'date' => $request->date,
                'receipt' => $receipt,
                'created_by' => $request->user()->id,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Expense recorded successfully',
                'data' => $expense,
            ], 201);
        });
    });

    // ==================== PRODUCT CATALOG ====================
    Route::prefix('products')->group(function () {

        Route::get('/', function (Request $request) {
            $query = ProductCatalog::with('category');

            if ($request->has('category_id')) {
                $query->where('category_id', $request->category_id);
            }

            if ($request->has('search')) {
                $search = $request->search;
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('code', 'like', "%{$search}%")
                      ->orWhere('description', 'like', "%{$search}%");
                });
            }

            $products = $query->orderBy('name')->get();

            return response()->json(['success' => true, 'data' => $products]);
        });

        Route::get('/categories', function () {
            $categories = ProductCategory::orderBy('name')->get();
            return response()->json(['success' => true, 'data' => $categories]);
        });
    });

    // ==================== MILESTONES ====================
    Route::prefix('milestones')->group(function () {

        Route::get('/', function (Request $request) {
            $query = ProjectMilestone::with('project');

            if ($request->has('project_id')) {
                $query->where('project_id', $request->project_id);
            }

            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            $milestones = $query->orderBy('milestone_number')->get();

            return response()->json(['success' => true, 'data' => $milestones]);
        });

        Route::get('/{id}', function ($id) {
            $milestone = ProjectMilestone::with('project')->find($id);

            if (!$milestone) {
                return response()->json(['success' => false, 'message' => 'Milestone not found'], 404);
            }

            return response()->json(['success' => true, 'data' => $milestone]);
        });

        // Update milestone progress (Surveyor role)
        Route::post('/{id}/update-progress', function (Request $request, $id) {
            if (!in_array($request->user()->role, ['surveyor', 'admin', 'project_manager'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'progress_percentage' => 'required|numeric|min:0|max:100',
                'status' => 'required|in:pending,in_progress,completed,delayed',
                'notes' => 'nullable|string',
                'photos.*' => 'nullable|image|max:5120',
            ]);

            $milestone = ProjectMilestone::find($id);
            if (!$milestone) {
                return response()->json(['success' => false, 'message' => 'Milestone not found'], 404);
            }

            // Handle photo uploads
            $photos = [];
            if ($request->hasFile('photos')) {
                foreach ($request->file('photos') as $photo) {
                    $path = $photo->store('milestone-photos', 'public');
                    $photos[] = $path;
                }
            }

            // Merge with existing photos
            $existingPhotos = json_decode($milestone->progress_photos ?? '[]', true);
            $allPhotos = array_merge($existingPhotos, $photos);

            $milestone->update([
                'progress_percentage' => $request->progress_percentage,
                'status' => $request->status,
                'progress_notes' => $request->notes,
                'progress_photos' => json_encode($allPhotos),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Milestone updated successfully',
                'data' => $milestone,
            ]);
        });
    });

    // ==================== LABOR MANAGEMENT ====================
    Route::prefix('labor')->group(function () {

        // Get all labor workers
        Route::get('/workers', function (Request $request) {
            if (!in_array($request->user()->role, ['finance', 'admin', 'ceo'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $workers = LaborWorker::orderBy('name')->get();
            return response()->json(['success' => true, 'data' => $workers]);
        });

        // Get labor payments
        Route::get('/payments', function (Request $request) {
            if (!in_array($request->user()->role, ['finance', 'admin', 'ceo'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $query = LaborPayment::with(['worker', 'paidBy']);

            if ($request->has('worker_id')) {
                $query->where('worker_id', $request->worker_id);
            }

            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            $perPage = $request->get('per_page', 20);
            $payments = $query->orderBy('payment_date', 'desc')->paginate($perPage);

            return response()->json([
                'success' => true,
                'data' => $payments->items(),
                'meta' => [
                    'current_page' => $payments->currentPage(),
                    'last_page' => $payments->lastPage(),
                    'total' => $payments->total(),
                ],
            ]);
        });

        // Create worker
        Route::post('/workers', function (Request $request) {
            if (!in_array($request->user()->role, ['finance', 'admin'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'name' => 'required|string|max:255',
                'phone' => 'nullable|string|max:255',
                'id_number' => 'nullable|string|max:255',
                'rate_type' => 'required|in:daily,monthly',
                'rate' => 'required|numeric|min:0',
                'bank_account' => 'nullable|string|max:255',
                'nssf_number' => 'nullable|string|max:255',
            ]);

            $worker = LaborWorker::create($request->all());

            return response()->json([
                'success' => true,
                'message' => 'Worker created successfully',
                'data' => $worker,
            ], 201);
        });
    });

    // ==================== SUBCONTRACTORS ====================
    Route::prefix('subcontractors')->group(function () {

        Route::get('/', function () {
            $subcontractors = Subcontractor::orderBy('name')->get();
            return response()->json(['success' => true, 'data' => $subcontractors]);
        });

        Route::get('/{id}', function ($id) {
            $subcontractor = Subcontractor::with(['projectContracts', 'payments'])->find($id);

            if (!$subcontractor) {
                return response()->json(['success' => false, 'message' => 'Subcontractor not found'], 404);
            }

            return response()->json(['success' => true, 'data' => $subcontractor]);
        });

        Route::post('/', function (Request $request) {
            if (!in_array($request->user()->role, ['admin', 'finance'])) {
                return response()->json(['success' => false, 'message' => 'Access denied'], 403);
            }

            $request->validate([
                'name' => 'required|string|max:255',
                'contact_person' => 'nullable|string|max:255',
                'phone' => 'nullable|string|max:255',
                'email' => 'nullable|email',
                'address' => 'nullable|string',
            ]);

            $subcontractor = Subcontractor::create($request->all());

            return response()->json([
                'success' => true,
                'message' => 'Subcontractor created successfully',
                'data' => $subcontractor,
            ], 201);
        });
    });

    // ==================== NOTIFICATIONS ====================
    Route::prefix('notifications')->group(function () {

        Route::get('/', function (Request $request) {
            $notifications = InAppNotification::where('user_id', $request->user()->id)
                ->orderBy('created_at', 'desc')
                ->take(50)
                ->get();

            return response()->json(['success' => true, 'data' => $notifications]);
        });

        Route::post('/{id}/read', function (Request $request, $id) {
            $notification = InAppNotification::where('user_id', $request->user()->id)
                ->where('id', $id)
                ->first();

            if (!$notification) {
                return response()->json(['success' => false, 'message' => 'Notification not found'], 404);
            }

            $notification->update(['read_at' => now()]);

            return response()->json(['success' => true, 'message' => 'Notification marked as read']);
        });

        Route::post('/mark-all-read', function (Request $request) {
            InAppNotification::where('user_id', $request->user()->id)
                ->whereNull('read_at')
                ->update(['read_at' => now()]);

            return response()->json(['success' => true, 'message' => 'All notifications marked as read']);
        });
    });

    // ==================== REPORTS ====================
    Route::prefix('reports')->group(function () {

        // Staff reports
        Route::get('/staff', function (Request $request) {
            $query = StaffReport::with('project');

            if ($request->has('project_id')) {
                $query->where('project_id', $request->project_id);
            }

            if ($request->has('report_type')) {
                $query->where('report_type', $request->report_type);
            }

            $perPage = $request->get('per_page', 20);
            $reports = $query->orderBy('date', 'desc')->paginate($perPage);

            return response()->json([
                'success' => true,
                'data' => $reports->items(),
                'meta' => [
                    'current_page' => $reports->currentPage(),
                    'last_page' => $reports->lastPage(),
                    'total' => $reports->total(),
                ],
            ]);
        });

        // QHSE reports
        Route::get('/qhse', function (Request $request) {
            $query = QhseReport::with('project');

            if ($request->has('project_id')) {
                $query->where('project_id', $request->project_id);
            }

            if ($request->has('report_type')) {
                $query->where('report_type', $request->report_type);
            }

            if ($request->has('severity')) {
                $query->where('severity', $request->severity);
            }

            $perPage = $request->get('per_page', 20);
            $reports = $query->orderBy('incident_date', 'desc')->paginate($perPage);

            return response()->json([
                'success' => true,
                'data' => $reports->items(),
                'meta' => [
                    'current_page' => $reports->currentPage(),
                    'last_page' => $reports->lastPage(),
                    'total' => $reports->total(),
                ],
            ]);
        });
    });
});
