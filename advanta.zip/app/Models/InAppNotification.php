<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class InAppNotification extends Model
{
    use HasFactory;

    protected $table = 'in_app_notifications';
    protected $fillable = ['user_id','type','data','read'];

    protected $casts = [
        'data' => 'array',
        'read' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
